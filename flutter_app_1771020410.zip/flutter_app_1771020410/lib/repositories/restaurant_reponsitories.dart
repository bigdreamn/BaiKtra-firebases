import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/menu_item_model.dart';
import '../models/reservation_model.dart';

class RestaurantRepository {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final String _menuCollection = 'menu_item';
  final String _resCollection =
      'reservations'; // Đảm bảo trùng tên trên Firebase Console

  // HÀM LẤY LỊCH SỬ ĐẶT BÀN (Đã sửa lỗi)
  Future<List<ReservationModel>> getAllReservations() async {
    try {
      final snapshot = await _db
          .collection(_resCollection)
          .orderBy('reservationDate', descending: true) // Mới nhất hiện lên đầu
          .get();

      return snapshot.docs.map((doc) {
        return ReservationModel.fromMap(doc.data(), doc.id);
      }).toList();
    } catch (e) {
      print("Lỗi lấy lịch sử: $e");
      return [];
    }
  }

  // HÀM ĐẶT BÀN
  Future<void> createReservation(ReservationModel res) async {
    try {
      await _db.collection(_resCollection).add(res.toMap());
    } catch (e) {
      print("Lỗi lưu đặt bàn: $e");
      rethrow;
    }
  }

  // Các hàm khác giữ nguyên...
  Future<List<MenuItemModel>> getFullMenu() async {
    final snapshot = await _db.collection(_menuCollection).get();
    return snapshot.docs
        .map((doc) => MenuItemModel.fromMap(doc.data(), doc.id))
        .toList();
  }

  Future<List<MenuItemModel>> searchMenuItems(String query) async {
    final allItems = await getFullMenu();
    final lowerQuery = query.toLowerCase();
    return allItems.where((item) {
      return item.name.toLowerCase().contains(lowerQuery) ||
          item.ingredients.any((ing) => ing.toLowerCase().contains(lowerQuery));
    }).toList();
  }
}
