import 'package:flutter/material.dart';
import '../models/reservation_model.dart';
import '../repositories/restaurant_reponsitories.dart';

class ReservationScreen extends StatefulWidget {
  const ReservationScreen({super.key});

  @override
  State<ReservationScreen> createState() => _ReservationScreenState();
}

class _ReservationScreenState extends State<ReservationScreen> {
  final RestaurantRepository _repo = RestaurantRepository();
  final _formKey = GlobalKey<FormState>();
  final _idController = TextEditingController();
  final _itemsController = TextEditingController();
  DateTime _date = DateTime.now();

  // Hàm xử lý logic khi nhấn nút
  void _submit() async {
    if (_formKey.currentState!.validate()) {
      // 1. Tạo đối tượng Model từ thông tin nhập vào
      final res = ReservationModel(
        customerId: _idController.text.trim(),
        reservationDate: _date,
        menuItemIds: _itemsController.text
            .split(',')
            .map((e) => e.trim())
            .where((e) => e.isNotEmpty) // Loại bỏ các khoảng trống thừa
            .toList(),
      );

      try {
        // 2. Gọi hàm lưu vào Firestore
        await _repo.createReservation(res);

        if (!mounted) return;

        // 3. Thông báo thành công với SnackBar
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Row(
              children: [
                Icon(Icons.check_circle, color: Colors.white),
                SizedBox(width: 10),
                Text("Đặt bàn thành công!"),
              ],
            ),
            backgroundColor: Colors.green,
            behavior: SnackBarBehavior.floating,
          ),
        );

        // 4. Quay lại trang chủ ngay lập tức
        Navigator.pop(context);
      } catch (e) {
        // Xử lý khi có lỗi (ví dụ: mất mạng, sai cấu hình Firebase)
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Lỗi: $e"),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Đặt bàn trực tuyến"),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(25.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Center(
                child: Icon(
                  Icons.calendar_month,
                  size: 80,
                  color: Colors.orange,
                ),
              ),
              const SizedBox(height: 30),

              // Ô nhập ID khách hàng
              const Text(
                "Thông tin khách hàng",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: _idController,
                decoration: InputDecoration(
                  labelText: "Số điện thoại hoặc mã ID",
                  hintText: "Nhập SĐT để chúng tôi liên lạc",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  prefixIcon: const Icon(Icons.person),
                ),
                validator: (v) =>
                    (v == null || v.isEmpty) ? "Không được để trống" : null,
              ),

              const SizedBox(height: 20),

              // Ô nhập danh sách món ăn
              const Text(
                "Món ăn muốn đặt trước",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: _itemsController,
                decoration: InputDecoration(
                  labelText: "Mã món ăn",
                  hintText: "Ví dụ: mon01, mon02, mon03",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  prefixIcon: const Icon(Icons.list_alt),
                ),
                validator: (v) =>
                    (v == null || v.isEmpty) ? "Nhập ít nhất 1 mã món" : null,
              ),

              const SizedBox(height: 20),

              // Hiển thị chọn ngày
              const Text(
                "Thời gian",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              ListTile(
                tileColor: Colors.orange[50],
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                title: Text("Ngày: ${_date.day}/${_date.month}/${_date.year}"),
                trailing: const Icon(Icons.edit_calendar, color: Colors.orange),
                onTap: () async {
                  final p = await showDatePicker(
                    context: context,
                    initialDate: _date,
                    firstDate: DateTime.now(),
                    lastDate: DateTime(2026),
                  );
                  if (p != null) setState(() => _date = p);
                },
              ),

              const SizedBox(height: 40),

              // Nút bấm xác nhận
              SizedBox(
                width: double.infinity,
                height: 55,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                  onPressed: _submit,
                  child: const Text(
                    "XÁC NHẬN ĐẶT BÀN",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
