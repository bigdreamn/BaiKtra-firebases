import 'package:cloud_firestore/cloud_firestore.dart';

class ReservationModel {
  final String? reservationId;
  final String customerId;
  final DateTime reservationDate;
  final List<String> menuItemIds; // Danh sách ID các món ăn khách chọn
  final String status; // "pending", "confirmed", "cancelled"

  ReservationModel({
    this.reservationId,
    required this.customerId,
    required this.reservationDate,
    required this.menuItemIds,
    this.status = 'pending',
  });

  factory ReservationModel.fromMap(Map<String, dynamic> data, String id) {
    return ReservationModel(
      reservationId: id,
      customerId: data['customerId'] ?? '',
      reservationDate: (data['reservationDate'] as Timestamp).toDate(),
      menuItemIds: List<String>.from(data['menuItemIds'] ?? []),
      status: data['status'] ?? 'pending',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'customerId': customerId,
      'reservationDate': Timestamp.fromDate(reservationDate),
      'menuItemIds': menuItemIds,
      'status': status,
    };
  }
}
