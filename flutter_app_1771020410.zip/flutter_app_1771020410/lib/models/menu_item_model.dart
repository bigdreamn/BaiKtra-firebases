class MenuItemModel {
  final String itemId;
  final String name;
  final String category;
  final double price;
  final List<String> ingredients;
  final bool isAvailable;
  final bool isSpicy;
  final int preparationTime;

  MenuItemModel({
    required this.itemId,
    required this.name,
    required this.category,
    required this.price,
    required this.ingredients,
    required this.isAvailable,
    required this.isSpicy,
    required this.preparationTime,
  });

  // Trong menu_item_model.dart
  factory MenuItemModel.fromMap(Map<String, dynamic> data, String id) {
    return MenuItemModel(
      itemId:
          data['itemId'] ??
          id, // Ưu tiên itemId trong field, nếu không có thì lấy doc.id
      name: data['name'] ?? '',
      category: data['category'] ?? '',
      price: (data['price'] ?? 0)
          .toDouble(), // Rất quan trọng để tránh trắng màn hình
      ingredients: List<String>.from(data['ingredients'] ?? []),
      isAvailable: data['isAvailable'] ?? true,
      isSpicy: data['isSpicy'] ?? false,
      preparationTime: data['preparationTime'] ?? 0,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'itemId': itemId,
      'name': name,
      'category': category,
      'price': price,
      'ingredients': ingredients,
      'isAvailable': isAvailable,
      'isSpicy': isSpicy,
      'preparationTime': preparationTime,
    };
  }
}
