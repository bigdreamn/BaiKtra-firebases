import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'screen/menu_screen.dart';
import 'screen/search_screen.dart';
import 'screen/reservation_screen.dart';
import 'screen/reservation_list_screen.dart';
import 'screen/login_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp(
      options: const FirebaseOptions(
        apiKey: "AIzaSyCSOateHOIG6UJcM61CDcVVecPNLYmTv7k",
        appId: "1:239022873408:web:81f5b59429b9429aff78a5",
        messagingSenderId: "239022873408",
        projectId: "flutterapp-1771020410",
        authDomain: "flutterapp-1771020410.firebaseapp.com",
        storageBucket: "flutterapp-1771020410.appspot.com",
      ),
    );
    runApp(const MyApp());
  } catch (e) {
    print("Lỗi khởi tạo Firebase: $e");
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.orange, useMaterial3: true),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // Lấy thông tin người dùng hiện tại
  User? user = FirebaseAuth.instance.currentUser;

  // Hàm đăng xuất
  void _logout() async {
    await FirebaseAuth.instance.signOut();
    setState(() {
      user = null;
    });
    if (mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Đã đăng xuất thành công!")));
    }
  }

  @override
  Widget build(BuildContext context) {
    // Lắng nghe thay đổi trạng thái đăng nhập để cập nhật giao diện
    FirebaseAuth.instance.authStateChanges().listen((User? newUser) {
      if (mounted) {
        setState(() {
          user = newUser;
        });
      }
    });

    return Scaffold(
      body: Column(
        children: [
          // Header Gradient với thông tin User
          Container(
            padding: const EdgeInsets.only(
              top: 60,
              left: 25,
              right: 20,
              bottom: 30,
            ),
            width: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.orange, Colors.deepOrange],
              ),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(30),
                bottomRight: Radius.circular(30),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "HƯƠNG VỊ VIỆT",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      user != null
                          ? "Chào, ${user!.email}"
                          : "Chào bạn, Khách hàng",
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
                if (user != null)
                  IconButton(
                    onPressed: _logout,
                    icon: const Icon(Icons.logout, color: Colors.white),
                    tooltip: "Đăng xuất",
                  ),
              ],
            ),
          ),

          Expanded(
            child: GridView.count(
              padding: const EdgeInsets.all(20),
              crossAxisCount: 2,
              crossAxisSpacing: 15,
              mainAxisSpacing: 15,
              children: [
                _card(
                  context,
                  "Thực đơn",
                  Icons.restaurant,
                  const MenuScreen(),
                  Colors.orange,
                ),
                _card(
                  context,
                  "Tìm kiếm",
                  Icons.search,
                  const SearchScreen(),
                  Colors.blue,
                ),
                _card(
                  context,
                  "Đặt bàn",
                  Icons.event_seat,
                  const ReservationScreen(),
                  Colors.green,
                ),
                _card(
                  context,
                  "Lịch sử",
                  Icons.history,
                  const ReservationListScreen(),
                  Colors.teal,
                ),
                _card(
                  context,
                  user != null ? "Tài khoản" : "Đăng nhập",
                  Icons.person,
                  const LoginScreen(),
                  Colors.purple,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _card(
    BuildContext context,
    String title,
    IconData icon,
    Widget page,
    Color color,
  ) {
    return InkWell(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => page),
      ),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 10),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40, color: color),
            const SizedBox(height: 10),
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}
