import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show kIsWeb;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    // Các nền tảng khác mặc định lấy từ file json/plist
    throw UnsupportedError(
      'DefaultFirebaseOptions are not supported for this platform.',
    );
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey:
        'AIzaSyCSOateHOIG6UJcM61CDcVVecPNLYmTv7k', // Copy từ Firebase Console
    appId:
        '1:239022873408:android:81f5b59429b9429aff78a5', // Copy từ Firebase Console
    messagingSenderId: '...',
    projectId: 'flutterapp-1771020410', // ID project của bạn
    authDomain: 'flutterapp-1771020410.firebaseapp.com',
    storageBucket: 'flutterapp-1771020410.appspot.com',
  );
}
